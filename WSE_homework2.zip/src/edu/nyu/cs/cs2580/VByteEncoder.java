package edu.nyu.cs.cs2580;

import java.util.ArrayList;

public class VByteEncoder
{

    public VByteEncoder()
    {
    }
    
    public static ArrayList<Byte> encode(ArrayList<Integer> nums)
    {
        ArrayList<Byte> byteStream = new ArrayList<>();
        for(int i=0;i<nums.size();i++)
        {
            ArrayList<Byte> array = encode(nums.get(i));
            byteStream.addAll(array);
        }
        return byteStream;
    }
    
    public static ArrayList<Byte> encode(int n)
    {
        ArrayList<Byte> array = new ArrayList<Byte>();
        
        while(true)
        {
            int x = n % 128;
            array.add(0, (byte)x);
            if(n < 128)
                break;
            
            n = n / 128;
        }
        byte newLast = (byte) ((byte)array.get(array.size()-1) | (byte)(1 << 7));
        array.set(array.size()-1, (byte)newLast);
        
        return array;
        
    }
    
    public static ArrayList<Integer> decode(ArrayList<Byte> list)
    {
        byte array[] = new byte[list.size()];
        for(int i=0;i<list.size();i++)
            array[i] = list.get(i);
        
        return decode(array);
    }
    public static ArrayList<Integer> decode(byte array[])
    {
        int n = 0;
        ArrayList<Integer> intArray = new ArrayList<>();
        for(int i=0;i<array.length;i++)
        {
            byte b = array[i];
            boolean last = ((b & (byte)(1 << 7)) != 0);
            if(!last)
                n = 128 * n + (int)b;
            else
            {
                n = 128 * n + (int) (b & (byte)127);
                intArray.add(n);
                //System.out.println(n);
                n = 0;
            }
        }
        return intArray;
    }
    
    public static void main(String[] args)
    {

        //convert(300);
        ArrayList<Integer> nums = new ArrayList<>();
        nums.add(1);
        nums.add(2);
        nums.add(2);
        nums.add(2);
        nums.add(1);
        nums.add(3);
        nums.add(7);
        nums.add(11);
        nums.add(5);
        nums.add(1);
        nums.add(2);
        nums.add(2);
        nums.add(4);
        nums.add(1);
        nums.add(2);
        nums.add(3);
        nums.add(10);
        
        ArrayList<Byte> array = VByteEncoder.encode(nums);
        for(int i=0;i<array.size();i++)
        {
            
            System.out.println(Integer.toHexString(array.get(i)));
        }
        
        
        ArrayList<Integer> nums2 = decode(array);
        for(int i=0;i<nums2.size();i++)
        {
            System.out.println(nums2.get(i));
        }
        for(int i=0;i<array.size();i++)
        {
            byte b1 = array.get(i);
            String s1 = String.format("%8s", Integer.toBinaryString(b1 & 0xFF)).replace(' ', '0');
            System.out.println(s1); // 10000001
            if((b1 & (byte)(1 << 7)) != 0)
                System.out.println("last");
        }
        
    }
}
